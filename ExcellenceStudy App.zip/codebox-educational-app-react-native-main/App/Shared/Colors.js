export default{
    primary:'#0C7DE4',
    white:'#fff',
    gray:'#979191',
    bgColor:'#F6F8FC',
    black:'#000',
    green:'#0CD650'

}